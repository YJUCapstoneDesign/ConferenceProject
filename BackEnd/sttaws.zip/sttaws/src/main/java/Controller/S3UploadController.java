package Controller;

import org.example.sttaws.S3Uploader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.google.gson.JsonObject;

@RestController
public class S3UploadController {

    @Autowired
    private S3Uploader s3Uploader;

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestBody JsonObject jsonData) {
        String filePath = jsonData.get("filePath").getAsString();
        String objectKey = jsonData.get("objectKey").getAsString();

        try {
            s3Uploader.uploadFile(filePath, objectKey);
            return ResponseEntity.ok("File uploaded successfully.");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred while uploading file: " + e.getMessage());
        }
    }
}
