package org.example.sttaws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SttawsApplicationTests {

    @Test
    void contextLoads() {
    }

}
